// Image Slider Functionality
let currentSlide = 0;
let autoPlayInterval;
let isPaused = false;
const slideInterval = 7000; // 7 seconds

const sliderWrapper = document.getElementById('sliderWrapper');
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const playPauseBtn = document.getElementById('playPauseBtn');

function showSlide(index) {
  // Remove active class from all slides and dots
  slides.forEach((slide, i) => {
    slide.classList.remove('active');
    if (i === index) {
      slide.classList.add('active');
    }
  });
  
  dots.forEach((dot, i) => {
    dot.classList.remove('active');
    if (i === index) {
      dot.classList.add('active');
    }
  });
  
  // Update slider position
  sliderWrapper.style.transform = `translateX(-${index * 100}%)`;
  currentSlide = index;
}

function nextSlide() {
  const next = (currentSlide + 1) % slides.length;
  showSlide(next);
}

function prevSlide() {
  const prev = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(prev);
}

function startAutoPlay() {
  if (!isPaused) {
    autoPlayInterval = setInterval(() => {
      nextSlide();
    }, slideInterval);
  }
}

function stopAutoPlay() {
  clearInterval(autoPlayInterval);
}

function togglePlayPause() {
  isPaused = !isPaused;
  playPauseBtn.classList.toggle('paused', isPaused);
  
  if (isPaused) {
    stopAutoPlay();
  } else {
    startAutoPlay();
  }
}

// Event Listeners
if (nextBtn) {
  nextBtn.addEventListener('click', () => {
    nextSlide();
    stopAutoPlay();
    startAutoPlay();
  });
}

if (prevBtn) {
  prevBtn.addEventListener('click', () => {
    prevSlide();
    stopAutoPlay();
    startAutoPlay();
  });
}

if (playPauseBtn) {
  playPauseBtn.addEventListener('click', togglePlayPause);
}

// Dot navigation
if (dots.length > 0) {
  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      showSlide(index);
      stopAutoPlay();
      startAutoPlay();
    });
  });
}

// Pause on hover
const sliderContainer = document.querySelector('.image-slider');
if (sliderContainer) {
  sliderContainer.addEventListener('mouseenter', () => {
    stopAutoPlay();
  });
  
  sliderContainer.addEventListener('mouseleave', () => {
    if (!isPaused) {
      startAutoPlay();
    }
  });
}

// Initialize slider
if (slides.length > 0) {
  showSlide(0);
  startAutoPlay();
}

// Mobile navigation toggle
const navToggle = document.getElementById('navToggle');
const nav = document.querySelector('.nav');

if (navToggle) {
  navToggle.addEventListener('click', () => {
    nav.classList.toggle('mobile-open');
  });
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Intersection Observer for fade-in animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

// Observe all cards and sections
document.querySelectorAll('.topic-card, .benefit-card, .resource-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(el);
});

// Add scroll effect to header
let lastScroll = 0;
window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;
  const header = document.querySelector('.header');
  
  if (currentScroll > 100) {
    header.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
  } else {
    header.style.boxShadow = 'none';
  }
  
  lastScroll = currentScroll;
});

// Campus Search Interactions
const campusOptions = document.querySelectorAll('.campus-option');
const mapOptionHeader = document.getElementById('mapOption');
let mapClickCount = 0;

campusOptions.forEach(option => {
  const header = option.querySelector('.option-header');
  const headerId = header ? header.id : '';
  
  // Skip map option - handled separately
  if (headerId === 'mapOption') {
    if (header) {
      header.addEventListener('click', () => {
        mapClickCount++;
        
        if (mapClickCount === 1) {
          // First click - show simple map
          option.classList.add('active');
        } else if (mapClickCount === 2) {
          // Second click - go to full map page
          window.location.href = 'map-detailed.html';
        }
      });
    }
    return;
  }
  
  if (header) {
    header.addEventListener('click', () => {
      // Close other options
      campusOptions.forEach(opt => {
        const optHeader = opt.querySelector('.option-header');
        if (opt !== option && optHeader && optHeader.id !== 'mapOption') {
          opt.classList.remove('active');
        }
      });
      
      // Toggle current option
      option.classList.toggle('active');
    });
  }
});

// Reset map click count when map option is closed
const mapOptionElement = document.querySelector('#mapOption')?.closest('.campus-option');
if (mapOptionElement) {
  const observer = new MutationObserver(() => {
    if (!mapOptionElement.classList.contains('active')) {
      mapClickCount = 0;
    }
  });
  
  observer.observe(mapOptionElement, {
    attributes: true,
    attributeFilter: ['class']
  });
}
