// Login form handling
const loginForm = document.getElementById('loginForm');
const googleSignInBtn = document.getElementById('googleSignIn');

if (loginForm) {
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const userType = document.getElementById('userType').value;
    
    // Basic validation
    if (!email || !password || !userType) {
      showNotification('Please fill in all fields', 'error');
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      showNotification('Please enter a valid email address', 'error');
      return;
    }
    
    // Simulate login (in real app, this would be an API call)
    showNotification('Signing in...', 'info');
    
    setTimeout(() => {
      // Check credentials (demo: student@uts.edu.my / 8888)
      if (email === 'student@uts.edu.my' && password === '8888' && userType === 'student') {
        // Store login info
        localStorage.setItem('userEmail', email);
        localStorage.setItem('userType', userType);
        localStorage.setItem('isLoggedIn', 'true');
        
        showNotification('Login successful! Redirecting...', 'success');
        
        // Redirect to student dashboard
        setTimeout(() => {
          window.location.href = 'student-dashboard.html';
        }, 1500);
      } else if (userType === 'lecturer') {
        // Store login info for lecturer
        localStorage.setItem('userEmail', email);
        localStorage.setItem('userType', userType);
        localStorage.setItem('isLoggedIn', 'true');
        
        showNotification('Login successful! Redirecting...', 'success');
        
        // Redirect to lecturer dashboard (or homepage for now)
        setTimeout(() => {
          window.location.href = 'refresh-homepage.html';
        }, 1500);
      } else {
        // Invalid credentials
        showNotification('Invalid email or password. Demo: student@uts.edu.my / 8888', 'error');
      }
    }, 1000);
  });
}

// Google Sign In
if (googleSignInBtn) {
  googleSignInBtn.addEventListener('click', () => {
    showNotification('Redirecting to Google Sign In...', 'info');
    
    // In a real app, this would trigger Google OAuth
    // For now, simulate the process
    setTimeout(() => {
      showNotification('Google Sign In would be implemented here', 'info');
    }, 500);
  });
}

// Forgot Password
const forgotPasswordLink = document.querySelector('.forgot-password');
if (forgotPasswordLink) {
  forgotPasswordLink.addEventListener('click', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    
    if (email) {
      showNotification(`Password reset link sent to ${email}`, 'success');
    } else {
      const emailInput = prompt('Please enter your email address:');
      if (emailInput) {
        showNotification(`Password reset link sent to ${emailInput}`, 'success');
      }
    }
  });
}

// Notification system
function showNotification(message, type = 'info') {
  // Remove existing notification if any
  const existing = document.querySelector('.notification');
  if (existing) {
    existing.remove();
  }
  
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  
  // Style based on type
  const colors = {
    success: '#10B981',
    error: '#EF4444',
    info: '#3B82F6'
  };
  
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${colors[type] || colors.info};
    color: white;
    padding: 16px 24px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    animation: slideIn 0.3s ease;
    max-width: 400px;
    font-size: 14px;
    font-weight: 500;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
`;
document.head.appendChild(style);

// Check if user is already logged in
window.addEventListener('load', () => {
  const isLoggedIn = localStorage.getItem('isLoggedIn');
  const userEmail = localStorage.getItem('userEmail');
  
  if (isLoggedIn === 'true' && userEmail) {
    // Update profile dropdown or show user info
    console.log('User is logged in:', userEmail);
  }
});

// Form input enhancements
document.querySelectorAll('input, select').forEach(input => {
  input.addEventListener('focus', function() {
    this.parentElement.style.transform = 'scale(1.02)';
  });
  
  input.addEventListener('blur', function() {
    this.parentElement.style.transform = 'scale(1)';
  });
});
